import React, { useState } from 'react';
import { ChefHat, Wine, Coffee, UtensilsCrossed } from 'lucide-react';

// Menu data
const menuData = {
  starters: [
    {
      name: 'Carpaccio de Filé Migno',
      description: 'Finas fatias de filé mignon, rúcula, parmesão e molho de mostarda dijon.',
      price: 45.00
    },
    {
      name: 'Bruschetta al Pomodoro',
      description: 'Pão italiano grelhado com tomates frescos, manjericão e azeite extra virgem.',
      price: 32.00
    }
  ],
  mainCourses: [
    {
      name: 'Risoto de Cogumelos Silvestres',
      description: 'Arroz arbório cozido lentamente com cogumelos frescos, vinho branco e finalizado com trufa negra.',
      price: 89.00
    },
    {
      name: 'Filé ao Molho Madeira',
      description: 'Medalhão de filé mignon grelhado, molho madeira, purê de batatas e legumes salteados.',
      price: 98.00
    }
  ],
  desserts: [
    {
      name: 'Cheesecake de Frutas Vermelhas',
      description: 'Torta de cheesecake cremosa com calda de frutas vermelhas e crocante de amêndoas.',
      price: 32.00
    },
    {
      name: 'Tiramisù',
      description: 'Clássica sobremesa italiana com café, mascarpone e cacau em pó.',
      price: 35.00
    }
  ],
  drinks: [
    {
      name: 'Caipirinha de Morango',
      description: 'Cachaça artesanal, morangos frescos, açúcar e gelo.',
      price: 28.00
    },
    {
      name: 'Vinho Tinto Reserva',
      description: 'Taça de vinho tinto reserva da casa.',
      price: 42.00
    }
  ]
};

function MenuItem({ name, description, price }: { name: string; description: string; price: number }) {
  return (
    <div className="mb-8 border-b border-gold/20 pb-6 last:border-0">
      <div className="flex justify-between items-baseline">
        <h3 className="text-xl font-serif text-gold">{name}</h3>
        <span className="text-lg font-serif text-gold">R$ {price.toFixed(2)}</span>
      </div>
      <p className="text-gray-300 mt-2 italic">{description}</p>
    </div>
  );
}

function MenuSection({ title, items, icon: Icon }: { title: string; items: any[]; icon: any }) {
  return (
    <section className="mb-12">
      <div className="flex items-center gap-3 mb-8">
        <Icon className="w-8 h-8 text-gold" />
        <h2 className="text-2xl font-serif text-gold">{title}</h2>
      </div>
      <div>
        {items.map((item, index) => (
          <MenuItem key={index} {...item} />
        ))}
      </div>
    </section>
  );
}

function App() {
  const [activeSection, setActiveSection] = useState('welcome');

  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1614854262318-831574f15f1f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center bg-fixed">
      <div className="min-h-screen bg-black/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-6 py-12">
          {/* Header */}
          <header className="text-center mb-16">
            <h1 className="text-5xl font-serif text-gold mb-4">La Maison Dorée</h1>
            <p className="text-gray-300 italic">Cuisine d'excellence depuis 1998</p>
          </header>

          {/* Welcome Message */}
          {activeSection === 'welcome' && (
            <div className="text-center mb-16 animate-fade-in">
              <p className="text-xl text-gray-300 mb-8">
                Bem-vindo à La Maison Dorée, onde a tradição encontra a inovação em cada prato.
                Nossa cozinha celebra os melhores ingredientes em criações únicas e memoráveis.
              </p>
              <button
                onClick={() => setActiveSection('menu')}
                className="px-8 py-3 bg-gold/20 hover:bg-gold/30 text-gold border border-gold/50 rounded-full transition-all"
              >
                Ver Menu
              </button>
            </div>
          )}

          {/* Menu */}
          {activeSection === 'menu' && (
            <div className="animate-fade-in">
              <MenuSection title="Para Começar" items={menuData.starters} icon={UtensilsCrossed} />
              <MenuSection title="Especialidades da Casa" items={menuData.mainCourses} icon={ChefHat} />
              <MenuSection title="Para Finalizar" items={menuData.desserts} icon={Coffee} />
              <MenuSection title="Bebidas e Vinhos" items={menuData.drinks} icon={Wine} />

              {/* Footer */}
              <footer className="text-center mt-16 pt-8 border-t border-gold/20">
                <p className="text-gray-300 mb-4">
                  Obrigado por escolher La Maison Dorée. Esperamos vê-lo em breve!
                </p>
                <div className="text-sm text-gray-400">
                  <p>Rua das Flores, 123 - Centro</p>
                  <p>Tel: (11) 1234-5678</p>
                  <p>Terça a Domingo: 12h - 23h</p>
                </div>
              </footer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;